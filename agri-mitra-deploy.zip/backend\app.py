"""
Agri Mitra Backend – Flask app.
Run: python app.py  or  gunicorn -w 1 -b 0.0.0.0:5000 app:app
"""
import os
from flask import Flask, send_from_directory
from flask_cors import CORS
from config import Config
from database import init_db
from routes.auth import auth_bp
from routes.profile import profile_bp
from routes.ai import ai_bp

app = Flask(__name__, static_folder=None)
app.config["SECRET_KEY"] = Config.SECRET_KEY
app.config["MAX_CONTENT_LENGTH"] = Config.MAX_CONTENT_LENGTH
CORS(app, origins=["*"], allow_headers=["*"], supports_credentials=True)

# Register blueprints
app.register_blueprint(auth_bp)
app.register_blueprint(profile_bp)
app.register_blueprint(ai_bp)

# Init DB on startup
with app.app_context():
    init_db()

# Optional: serve frontend static files (for Replit single-repo)
FRONTEND = os.path.join(os.path.dirname(__file__), "..")
if os.path.isdir(FRONTEND):
    @app.route("/")
    def index():
        return send_from_directory(FRONTEND, "index.html")
    @app.route("/<path:path>")
    def frontend(path):
        if "." in path and os.path.isfile(os.path.join(FRONTEND, path)):
            return send_from_directory(FRONTEND, path)
        if not path.startswith("api") and not path.startswith("uploads"):
            return send_from_directory(FRONTEND, path)
        return {"error": "Not found"}, 404

@app.route("/api/health")
def health():
    return {"status": "ok", "service": "agri-mitra-backend"}

if __name__ == "__main__":
    port = int(os.getenv("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=os.getenv("FLASK_DEBUG", "0") == "1")
