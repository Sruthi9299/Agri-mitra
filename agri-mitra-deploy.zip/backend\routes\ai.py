"""AI voice assistant: /api/ask (text or audio) -> STT -> Gen AI -> translate -> TTS -> optional image."""
import os
import tempfile
from flask import Blueprint, request, jsonify, send_from_directory
from config import Config
from services.speech_to_text import transcribe_audio
from services.gen_ai import get_agri_response
from services.translate import translate_text
from services.text_to_speech import text_to_speech
from services.image_gen import generate_agri_image

ai_bp = Blueprint("ai", __name__, url_prefix="/api")

# Ensure uploads exist
os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)
os.makedirs(os.path.join(Config.UPLOAD_FOLDER, "tts"), exist_ok=True)
os.makedirs(os.path.join(Config.UPLOAD_FOLDER, "images"), exist_ok=True)

LANG_CODE_MAP = {"en": "en", "te": "te-IN", "hi": "hi-IN", "ta": "ta-IN"}

@ai_bp.route("/ask", methods=["POST"])
def ask():
    """
    Accepts:
    - JSON: { "text": "...", "language": "en" | "te" | "hi" | "ta" }
    - FormData: audio file + language
    Returns: { "text": "...", "audioUrl": "/uploads/tts/xxx.mp3" or null, "imageUrl": "/uploads/images/xxx.png" or null }
    """
    lang = (request.form.get("language") or request.get_json(silent=True) or {}).get("language") or "en"
    lang_code = LANG_CODE_MAP.get(lang, "en")
    stt_lang = lang_code if "-" in lang_code else (lang_code + "-IN")

    # 1) Get user text: from JSON or from audio (Speech-to-Text)
    user_text = None
    if request.is_json:
        data = request.get_json() or {}
        user_text = (data.get("text") or "").strip()
    if not user_text and request.files:
        audio_file = request.files.get("audio")
        if audio_file and audio_file.filename:
            ext = os.path.splitext(audio_file.filename)[1] or ".webm"
            fd, path = tempfile.mkstemp(suffix=ext)
            try:
                audio_file.save(path)
                user_text = transcribe_audio(path, stt_lang)
            finally:
                try:
                    os.close(fd)
                    os.unlink(path)
                except Exception:
                    pass
            if not user_text:
                return jsonify({"error": "Could not transcribe audio. Try typing your question.", "text": ""}), 400

    if not user_text:
        return jsonify({"error": "Provide 'text' in JSON or 'audio' file.", "text": ""}), 400

    # 2) Optional: translate user input to English for better AI (if not en)
    text_for_ai = user_text
    if lang != "en":
        text_for_ai = translate_text(user_text, "en", source_lang=lang if len(lang) == 2 else "en")
        if not text_for_ai:
            text_for_ai = user_text

    # 3) Gen AI (agriculture prompt)
    response_text = get_agri_response(text_for_ai, lang)

    # 4) Optional: translate response to user's language
    if lang != "en":
        response_text = translate_text(response_text, lang, source_lang="en") or response_text

    # 5) Text-to-Speech (server-side if configured)
    audio_url = None
    tts_path = text_to_speech(response_text, lang)
    if tts_path:
        audio_url = "/" + tts_path.lstrip("/")

    # 6) Optional: generate context image (DALL-E)
    image_url = None
    if Config.OPENAI_API_KEY:
        img_prompt = response_text[:200] + " farming"
        image_path = generate_agri_image(img_prompt)
        if image_path:
            image_url = "/" + image_path.lstrip("/")

    return jsonify({
        "text": response_text,
        "audioUrl": audio_url,
        "imageUrl": image_url,
    })


@ai_bp.route("/uploads/<path:subpath>")
def serve_upload(subpath):
    """Serve generated TTS/Images from uploads folder (e.g. /uploads/tts/xxx.mp3)."""
    full = os.path.join(Config.UPLOAD_FOLDER, subpath)
    if not os.path.exists(full) or not os.path.isfile(full):
        return jsonify({"error": "Not found"}), 404
    folder = os.path.dirname(full)
    name = os.path.basename(full)
    return send_from_directory(folder, name, as_attachment=False)
