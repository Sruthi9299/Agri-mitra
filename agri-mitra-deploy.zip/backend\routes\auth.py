"""Auth routes: register, login, OTP."""
from flask import Blueprint, request, jsonify
from database import get_connection
from utils.otp import generate_otp, get_demo_otp, is_demo_mode, verify_otp
from utils.auth import create_token

auth_bp = Blueprint("auth", __name__, url_prefix="/api")

@auth_bp.route("/send-otp", methods=["POST"])
def send_otp():
    data = request.get_json() or {}
    phone = (data.get("phone") or "").strip()
    if not phone or len(phone) != 10:
        return jsonify({"error": "Valid 10-digit phone required"}), 400
    otp = get_demo_otp() if is_demo_mode() else generate_otp(4)
    conn = get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("DELETE FROM otp_store WHERE phone = %s", (phone,))
            cur.execute("INSERT INTO otp_store (phone, otp) VALUES (%s, %s)", (phone, otp))
        return jsonify({"message": "OTP sent successfully", "demo_otp": otp if is_demo_mode() else None})
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        conn.close()

@auth_bp.route("/register", methods=["POST"])
def register():
    data = request.get_json() or {}
    phone = (data.get("phone") or "").strip()
    otp = (data.get("otp") or "").strip()
    full_name = (data.get("full_name") or "").strip()
    age = data.get("age")
    dob = data.get("dob")
    preferred_language = (data.get("preferred_language") or "English").strip()
    location = (data.get("location") or "").strip()
    soil_type = (data.get("soil_type") or "").strip()

    if not all([phone, full_name]):
        return jsonify({"error": "Phone and full name required"}), 400
    if len(phone) != 10:
        return jsonify({"error": "Phone must be 10 digits"}), 400

    conn = get_connection()
    try:
        with conn.cursor() as cur:
            if not (is_demo_mode() and otp == get_demo_otp()):
                cur.execute("SELECT id FROM otp_store WHERE phone = %s AND otp = %s", (phone, otp))
                if not cur.fetchone():
                    return jsonify({"error": "Invalid or expired OTP"}), 400
            cur.execute("SELECT id FROM users WHERE phone = %s", (phone,))
            if cur.fetchone():
                return jsonify({"error": "Phone already registered"}), 400
            cur.execute(
                """INSERT INTO users (full_name, phone, age, dob, preferred_language, location, soil_type)
                   VALUES (%s, %s, %s, %s, %s, %s, %s)""",
                (full_name, phone, age, dob or None, preferred_language, location, soil_type),
            )
            user_id = cur.lastrowid
        token = create_token(user_id, phone)
        return jsonify({"message": "Registered successfully", "token": token, "user_id": user_id})
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        conn.close()

@auth_bp.route("/login", methods=["POST"])
def login():
    data = request.get_json() or {}
    phone = (data.get("phone") or "").strip()
    otp = (data.get("otp") or "").strip()
    user_name = (data.get("user_name") or "").strip()  # optional display name check

    if not phone or len(phone) != 10:
        return jsonify({"error": "Valid 10-digit phone required"}), 400
    if not otp:
        return jsonify({"error": "OTP required"}), 400

    conn = get_connection()
    try:
        with conn.cursor() as cur:
            if not (is_demo_mode() and otp == get_demo_otp()):
                cur.execute("SELECT id FROM otp_store WHERE phone = %s AND otp = %s", (phone, otp))
                if not cur.fetchone():
                    return jsonify({"error": "Invalid or expired OTP"}), 400
            cur.execute("SELECT id, full_name, phone FROM users WHERE phone = %s", (phone,))
            row = cur.fetchone()
            if not row:
                return jsonify({"error": "Phone not registered. Please register first."}), 400
            user_id, full_name, _ = row["id"], row["full_name"], row["phone"]
        token = create_token(user_id, phone)
        return jsonify({
            "message": "Login successful",
            "token": token,
            "user_id": user_id,
            "full_name": full_name,
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        conn.close()
