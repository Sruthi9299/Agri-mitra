"""Profile and current user routes."""
from flask import Blueprint, request, jsonify
from database import get_connection
from utils.auth import verify_token

profile_bp = Blueprint("profile", __name__, url_prefix="/api")

def get_user_id_from_request():
    auth = request.headers.get("Authorization") or request.args.get("token")
    if not auth or not auth.startswith("Bearer "):
        token = request.headers.get("X-Token") or request.args.get("token")
    else:
        token = auth.replace("Bearer ", "")
    if not token:
        return None
    user_id, _ = verify_token(token)
    return user_id

@profile_bp.route("/me", methods=["GET"])
def me():
    """Return current user summary for navbar (name)."""
    user_id = get_user_id_from_request()
    if not user_id:
        return jsonify({"full_name": None, "logged_in": False})
    conn = get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT full_name FROM users WHERE id = %s", (user_id,))
            row = cur.fetchone()
            if not row:
                return jsonify({"full_name": None, "logged_in": False})
            return jsonify({"full_name": row["full_name"], "logged_in": True})
    finally:
        conn.close()

@profile_bp.route("/profile", methods=["GET"])
def get_profile():
    """Full profile for user.html (farmer details, crop, photos)."""
    user_id = get_user_id_from_request()
    if not user_id:
        return jsonify({"error": "Login required"}), 401
    conn = get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(
                """SELECT full_name, phone, age, dob, preferred_language, location, soil_type, profile_image_url
                   FROM users WHERE id = %s""",
                (user_id,),
            )
            user = cur.fetchone()
            if not user:
                return jsonify({"error": "User not found"}), 404
            cur.execute(
                """SELECT crop_name, sowing_date, stage, description FROM user_crops WHERE user_id = %s ORDER BY id DESC LIMIT 1""",
                (user_id,),
            )
            crop = cur.fetchone()
            cur.execute(
                """SELECT file_path FROM user_photos WHERE user_id = %s ORDER BY id DESC LIMIT 20""",
                (user_id,),
            )
            photos = [r["file_path"] for r in cur.fetchall()]
        # Format for frontend (same UI structure)
        dob_str = user["dob"].strftime("%Y-%m-%d") if user.get("dob") else None
        return jsonify({
            "farmer": {
                "name": user["full_name"] or "Farmer",
                "location": user["location"] or "—",
                "land_size": "—",  # add column if needed
                "experience": "—",
                "profile_image_url": user.get("profile_image_url") or "https://images.unsplash.com/photo-1595152772835-219674b2a8a6",
            },
            "crop": {
                "crop": crop["crop_name"] if crop else "—",
                "sowing_date": crop["sowing_date"].strftime("%d-%b-%Y") if crop and crop.get("sowing_date") else "—",
                "stage": crop["stage"] if crop else "—",
                "description_points": (crop.get("description") or "").split("\n") if crop else [],
            },
            "photos": photos if photos else [
                "https://images.unsplash.com/photo-1560493676-04071c5f467b",
                "https://images.unsplash.com/photo-1501004318641-b39e6451bec6",
                "https://th.bing.com/th/id/OIP.D3Rsifcxqt-0tduFcE4C5QHaEK?w=333&h=187&c=7&r=0&o=7&dpr=1.3&pid=1.7&rm=3",
            ],
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        conn.close()
