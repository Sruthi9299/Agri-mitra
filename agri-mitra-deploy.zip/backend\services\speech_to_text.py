"""Speech-to-Text: Google Cloud Speech, OpenAI Whisper, or fallback."""
import os
from config import Config

def transcribe_audio(audio_path: str, language_code: str = "en-IN") -> str:
    """
    Transcribe audio file to text.
    language_code: en-IN, te-IN, hi-IN, ta-IN, etc.
    Uses OpenAI Whisper if OPENAI_API_KEY set (accepts webm); else Google Cloud Speech.
    """
    if not os.path.exists(audio_path):
        return ""
    # OpenAI Whisper (accepts webm/mp3/mp4 etc.)
    if Config.OPENAI_API_KEY:
        try:
            from openai import OpenAI
            client = OpenAI(api_key=Config.OPENAI_API_KEY)
            with open(audio_path, "rb") as f:
                r = client.audio.transcriptions.create(model="whisper-1", file=f, language=(language_code or "en")[:2])
            return (r.text or "").strip()
        except Exception as e:
            print("Whisper STT error:", e)
    try:
        from google.cloud import speech
        client = speech.SpeechClient()
        with open(audio_path, "rb") as f:
            content = f.read()
        audio = speech.RecognitionAudio(content=content)
        enc = speech.RecognitionConfig.AudioEncoding.LINEAR16
        if audio_path.endswith(".webm"):
            enc = speech.RecognitionConfig.AudioEncoding.WEBM_OPUS
        config = speech.RecognitionConfig(
            encoding=enc,
            sample_rate_hertz=48000 if enc == speech.RecognitionConfig.AudioEncoding.WEBM_OPUS else 16000,
            language_code=language_code or "en-IN",
        )
        response = client.recognize(config=config, audio=audio)
        text = " ".join(r.alternatives[0].transcript for r in response.results)
        return text.strip()
    except ImportError:
        pass
    except Exception as e:
        print("Google STT error:", e)
    return ""
