"""Text-to-Speech: Google TTS, Azure TTS, or none (browser TTS)."""
import os
import uuid
from config import Config

def tts_file_path():
    d = Config.UPLOAD_FOLDER
    os.makedirs(os.path.join(d, "tts"), exist_ok=True)
    return os.path.join(d, "tts", f"{uuid.uuid4().hex}.mp3")

def text_to_speech(text: str, language_code: str) -> str:
    """
    Generate speech file. Returns path relative to uploads for URL, or empty if not available.
    language_code: en, te, hi, ta -> en-US, te-IN, hi-IN, ta-IN
    """
    if not text:
        return ""
    provider = (Config.TTS_PROVIDER or "browser").lower()
    lang_map = {"en": "en-US", "te": "te-IN", "hi": "hi-IN", "ta": "ta-IN"}
    lang = lang_map.get(language_code, "en-US")
    out_path = tts_file_path()
    if provider == "azure" and Config.AZURE_SPEECH_KEY and Config.AZURE_SPEECH_REGION:
        return _azure_tts(text, lang, out_path)
    if provider == "google":
        return _google_tts(text, lang, out_path)
    return ""

def _google_tts(text: str, lang: str, out_path: str) -> str:
    try:
        from google.cloud import texttospeech
        client = texttospeech.TextToSpeechClient()
        synthesis_input = texttospeech.SynthesisInput(text=text)
        voice = texttospeech.VoiceSelectionParams(language_code=lang[:2] + "-IN" if lang.startswith("te") or lang.startswith("hi") or lang.startswith("ta") else lang, name=None)
        audio_config = texttospeech.AudioConfig(audio_encoding=texttospeech.AudioEncoding.MP3)
        response = client.synthesize_speech(input=synthesis_input, voice=voice, audio_config=audio_config)
        with open(out_path, "wb") as f:
            f.write(response.audio_content)
        return os.path.join("uploads", "tts", os.path.basename(out_path)).replace("\\", "/")
    except Exception as e:
        print("Google TTS error:", e)
    return ""

def _azure_tts(text: str, lang: str, out_path: str) -> str:
    try:
        import azure.cognitiveservices.speech as speechsdk
        speech_config = speechsdk.SpeechConfig(subscription=Config.AZURE_SPEECH_KEY, region=Config.AZURE_SPEECH_REGION)
        speech_config.speech_synthesis_voice_name = _azure_voice(lang)
        audio_config = speechsdk.audio.AudioOutputConfig(filename=out_path)
        synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config, audio_config=audio_config)
        result = synthesizer.speak_text_async(text).get()
        if result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
            return os.path.join("uploads", "tts", os.path.basename(out_path)).replace("\\", "/")
    except Exception as e:
        print("Azure TTS error:", e)
    return ""

def _azure_voice(lang: str) -> str:
    voices = {"en-US": "en-US-JennyNeural", "te-IN": "te-IN-MohanNeural", "hi-IN": "hi-IN-SwaraNeural", "ta-IN": "ta-IN-PallaviNeural"}
    return voices.get(lang, "en-US-JennyNeural")
