"""Translation: Google Cloud Translation API (optional)."""
from config import Config

LANG_MAP = {
    "en": "en",
    "te": "te",  # Telugu
    "hi": "hi",  # Hindi
    "ta": "ta",  # Tamil
    "mr": "mr",
    "kn": "kn",
}

def translate_text(text: str, target_lang: str, source_lang: str = "en") -> str:
    """Translate text to target language. Returns original if API not configured."""
    if not text or target_lang == "en" or target_lang == source_lang:
        return text
    try:
        from google.cloud import translate_v2 as translate
        client = translate.Client()
        result = client.translate(text, target_language=target_lang, source_language=source_lang)
        return result.get("translatedText", text)
    except ImportError:
        pass
    except Exception as e:
        print("Translation error:", e)
    # Alternative: requests to Google Translate API (API key)
    if Config.GOOGLE_TRANSLATE_API_KEY:
        try:
            import requests
            url = "https://translation.googleapis.com/language/translate/v2"
            r = requests.post(
                url,
                params={"key": Config.GOOGLE_TRANSLATE_API_KEY},
                json={"q": text, "source": source_lang, "target": target_lang, "format": "text"},
                timeout=10,
            )
            if r.ok:
                data = r.json()
                return data.get("data", {}).get("translations", [{}])[0].get("translatedText", text)
        except Exception as e:
            print("Translate API error:", e)
    return text
