"""JWT-like token for session (simple signed token)."""
from itsdangerous import URLSafeTimedSerializer
from config import Config

serializer = URLSafeTimedSerializer(Config.SECRET_KEY, salt="agri-auth")

def create_token(user_id, phone):
    return serializer.dumps({"user_id": user_id, "phone": phone})

def verify_token(token, max_age=7 * 24 * 3600):
    """Max age in seconds (default 7 days)."""
    try:
        data = serializer.loads(token, salt="agri-auth", max_age=max_age)
        return data.get("user_id"), data.get("phone")
    except Exception:
        return None, None
