"""OTP generation and verification (demo-friendly)."""
import random
import string
from datetime import datetime, timedelta
from config import Config

def generate_otp(length=4):
    return "".join(random.choices(string.digits, k=length))

def get_demo_otp():
    return Config.OTP_DEMO

def is_demo_mode():
    return Config.OTP_DEMO and len(Config.OTP_DEMO) == 4

def verify_otp(phone, otp, cursor=None):
    """Verify OTP. In demo mode, accept OTP_DEMO for any phone."""
    if is_demo_mode() and otp == get_demo_otp():
        return True
    if not cursor:
        return False
    cursor.execute(
        "SELECT id FROM otp_store WHERE phone = %s AND otp = %s AND created_at > %s",
        (phone, otp, datetime.utcnow() - timedelta(minutes=Config.OTP_EXPIRE_MINUTES)),
    )
    return cursor.fetchone() is not None
