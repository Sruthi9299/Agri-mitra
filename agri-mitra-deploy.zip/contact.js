// Form submission alert
document.getElementById('supportForm').addEventListener('submit', function(e){
    e.preventDefault();
    alert('Thank you! Your message has been sent to support.');
});